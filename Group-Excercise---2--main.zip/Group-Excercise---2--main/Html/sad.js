function toggleTheme() {
    const body = document.body;
    body.classList.toggle('night-theme');
}